# -*- coding: utf-8 -*-
"""
    health
    ~~~~~
    用于健康模型预测
"""